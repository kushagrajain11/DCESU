from django import forms
from .import models

class SocietyForm(forms.Form):
	name = forms.CharField(max_length = 20)
	description = forms.CharField(max_length = 1000)
	contact_info = forms.CharField(max_length = 50)