from django.apps import AppConfig


class SocietyConfig(AppConfig):
    name = 'society'
